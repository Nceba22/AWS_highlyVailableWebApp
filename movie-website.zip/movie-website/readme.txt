This website demostrate aan online move store website.

Customers can view move prices, ratings  and decide which move to buy.

Website page:

http://movie-website.s3-website-us-east-1.amazonaws.com/

CloudFront ditribution:

https://d3idxpsmkv6tf1.cloudfront.net/